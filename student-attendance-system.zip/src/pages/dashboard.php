<div class="jumbotron">
    <h1 class="display-4">Welcome, Admin!</h1>
    <p class="lead">This is the central dashboard for the Student Attendance System.</p>
    <hr class="my-4">
    <p>From here, you can manage students, teachers, and view attendance records. Use the navigation bar above to get started.</p>
    <a class="btn btn-primary btn-lg" href="index.php?page=students" role="button">Manage Students</a>
</div>